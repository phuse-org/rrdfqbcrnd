File needed else directory omitted by rbuild
