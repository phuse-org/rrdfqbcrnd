RDF Cube Validation Result
==========================

Validator: NoSPA
Wed Jun 29 22:18:57 CEST 2016
DC-DEMO-sample.ttl

Integrity Constraint 1: Unique DataSet
--------------------------------------

Pass.

Integrity Constraint 2: Unique DSD
----------------------------------

Pass.

Integrity Constraint 3: DSD Includes Measure
--------------------------------------------

Pass.

Integrity Constraint 4: Dimensions Have Range
---------------------------------------------

Pass.

Integrity Constraint 5: Concept Dimensions Have Code Lists
----------------------------------------------------------

Pass.

Integrity Constraint 6: Only Attributes May Be Optional
-------------------------------------------------------

Pass.

Integrity Constraint 7: Slice Keys Must Be Declared
---------------------------------------------------

Pass.

Integrity Constraint 8: Slice Keys Consistent With DSD
------------------------------------------------------

Pass.

Integrity Constraint 9: Unique Slice Structure
----------------------------------------------

Pass.

Integrity Constraint 10: Slice Dimensions Complete
--------------------------------------------------

Pass.

Integrity Constraint 11: All Dimensions Required
------------------------------------------------

Pass.

Integrity Constraint 12: No Duplicate Observations
--------------------------------------------------

Pass.

Integrity Constraint 13: Required Attributes
--------------------------------------------

Pass.

Integrity Constraint 14: All Measures Present
---------------------------------------------

Pass.

Integrity Constraint 15: Measure Dimension Consistent
-----------------------------------------------------

Pass.

Integrity Constraint 16: Single Measure On Measure Dimension Observation
------------------------------------------------------------------------

Pass.

Integrity Constraint 17: All Measures Present In Measures Dimension Cube
------------------------------------------------------------------------

Pass.

Integrity Constraint 18: Consistent Dataset Links
-------------------------------------------------

Pass.

Integrity Constraint 19: Codes From Code List
---------------------------------------------

Pass.

Integrity Constraint 20: Codes From Hierarchy
---------------------------------------------

Pass.

Integrity Constraint 21: Codes From Hierarchy (Inverse)
-------------------------------------------------------

Pass.

