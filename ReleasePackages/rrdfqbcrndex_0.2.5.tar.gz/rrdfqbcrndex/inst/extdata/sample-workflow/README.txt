Source for demo.sas:
https://code.google.com/p/phuse-scripts/source/browse/trunk/whitepapers/demographics/demo.sas
